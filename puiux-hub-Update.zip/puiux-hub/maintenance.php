<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

header('HTTP/1.1 503 Service Unavailable', true, 503);
header('Retry-After: 3600'); // Suggest browser to retry after 1 hour

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintenance Mode</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            width: 100vw;
            background-color: #ffffff;
            font-family: Arial, sans-serif;
            margin: 0;
            overflow: hidden; /* Prevent scrolling */
        }
        .puiux-server-payment {
            text-align: center;
            background: rgb(255 255 255);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 100%;
            position: fixed;
            z-index: 10;
            height: auto;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .puiux-server-payment::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: #fff;
            opacity: 1;
            z-index: 1;
            border-radius: 8px;
        }
        .body-content-message {
            background-color: #fff;
            z-index: 99999999999;
            direction: rtl;
            font-family: 'cairo';
        }
        .animation {
            width: 350px;
            height: 350px;
            margin: 0 auto;
        }
        .title {
            font-size: 24px;
            font-weight: bold;
            margin-top: 20px;
        }
        .description {
            font-size: 16px;
            margin-top: 10px;
        }
        .buttons-message-puiux {
            margin-top: 20px;
            display: flex;
            justify-content: space-around;
            width: 100%;
        }
        .button-message-puiux {
            background-color: #000;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s, color 0.3s;
            border: 2px solid #000;
            width: 50%;
            margin: 0 10px;
        }
        .button-message-puiux:hover {
            background-color: #fff;
            color: #000;
            border: 2px solid #000;
        }
    </style>
</head>
<body>
    <div class="puiux-server-payment">
        <div class="body-content-message">
            <div id="animation" class="animation"></div>
            <div class="title">الموقع مغلق لعدم التجديد</div>
            <div class="description">يرجى التواصل مع الدعم الفني للتجديد واستعادة الوصول إلى الموقع.</div>
            <div class="buttons-message-puiux">
                <a href="https://puiux.info/unique/" class="button-message-puiux" target="_blank">تواصل مع الدعم</a>
                <a href="https://wa.me/966544420258" class="button-message-puiux" target="_blank">تواصل واتساب</a>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bodymovin/5.7.4/lottie.min.js"></script>
    <script>
        lottie.loadAnimation({
            container: document.getElementById('animation'),
            renderer: 'svg',
            loop: true,
            autoplay: true,
            path: 'https://lottie.host/8838f04b-0790-41d5-97e8-d89fe73a0be2/Cquwp9MMbG.json'
        });
    </script>
</body>
</html>
