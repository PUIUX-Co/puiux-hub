<?php
/*
Plugin Name: PUIUX Hub
Plugin URI: https://puiux.com
Description: The ultimate solution for integrating and managing multiple PUIUX products seamlessly within WordPress.
Version: 1.0
Author: PUIUX
Author URI: https://puiux.com
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Load text domain for translations
function puiux_hub_load_textdomain() {
    load_plugin_textdomain('puiux-hub', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'puiux_hub_load_textdomain');

// Activation and Deactivation hooks
function puiux_hub_activate() {
    add_option('puiux_hub_do_activation_redirect', true);
}
register_activation_hook(__FILE__, 'puiux_hub_activate');

function puiux_hub_deactivate() {
    // Actions to perform upon plugin deactivation
    delete_option('puiux_maintenance_mode'); // Remove maintenance mode on deactivation
}
register_deactivation_hook(__FILE__, 'puiux_hub_deactivate');

// Include necessary files
require_once(plugin_dir_path(__FILE__) . 'includes/admin/puiux-admin-page.php');
require_once(plugin_dir_path(__FILE__) . 'includes/admin/puiux-settings.php');
require_once(plugin_dir_path(__FILE__) . 'includes/admin/puiux-activation-page.php');
require_once(plugin_dir_path(__FILE__) . 'includes/admin/puiux-puipedia.php');
require_once(plugin_dir_path(__FILE__) . 'includes/sub-plugins/puiux-renewal-alert/puiux-renewal-alert.php'); // Include the renewal alert plugin
require_once(plugin_dir_path(__FILE__) . 'includes/frontend/puiux-frontend-functions.php');
require_once(plugin_dir_path(__FILE__) . 'info/puiux-rights.php'); // Include rights page
require_once(plugin_dir_path(__FILE__) . 'maintenance.php'); // Include maintenance mode

// Include admin footer rights
function puiux_include_admin_footer_rights() {
    include(plugin_dir_path(__FILE__) . 'info/puiux-admin-footer-rights.php');
    if (function_exists('puiux_admin_footer_rights')) {
        add_filter('admin_footer_text', 'puiux_admin_footer_rights');
    }
}
add_action('admin_init', 'puiux_include_admin_footer_rights');

// Enqueue scripts and styles
function puiux_hub_enqueue_scripts($hook_suffix) {
    // Check if we are on the plugin's admin page
    $admin_pages = array(
        'toplevel_page_puiux-hub',
        'puiux-hub_page_puiux-hub-settings',
        'puiux-hub_page_puiux-hub-activation',
        'puiux-hub_page_puiux-hub-puipedia',
        'puiux-hub_page_puiux-renewal-alert',
        'puiux-hub_page_puiux-rights'
    );

    if (in_array($hook_suffix, $admin_pages)) {
        wp_enqueue_style('puiux-hub-style', plugins_url('assets/css/puiux-style.css', __FILE__));
        wp_enqueue_script('puiux-hub-script', plugins_url('assets/js/puiux-script.js', __FILE__), array('jquery'), null, true);
        wp_enqueue_script('lottie', 'https://cdnjs.cloudflare.com/ajax/libs/bodymovin/5.7.4/lottie.min.js', array(), null, true);

        // Load FancyBox CSS and JS
        wp_enqueue_style('fancybox', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css');
        wp_enqueue_script('fancybox', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js', array('jquery'), null, true);

        // Load Sortable JS
        wp_enqueue_script('sortable', 'https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.14.0/Sortable.min.js', array('jquery'), null, true);
    }
    wp_localize_script('puiux-hub-script', 'puiux_hub_settings', array(
        'video_title' => __('Video Title', 'puiux-hub'),
        'video_url' => __('Video URL', 'puiux-hub'),
        'thumbnail_url' => __('Thumbnail URL', 'puiux-hub'),
        'remove' => __('Remove', 'puiux-hub')
    ));
}
add_action('admin_enqueue_scripts', 'puiux_hub_enqueue_scripts');

// Redirect to custom page on activation
function puiux_hub_activation_redirect() {
    if (get_option('puiux_hub_do_activation_redirect', false)) {
        delete_option('puiux_hub_do_activation_redirect');
        if (!isset($_GET['activate-multi'])) {
            wp_safe_redirect(admin_url('admin.php?page=puiux-hub-activation'));
            exit;
        }
    }
}
add_action('admin_init', 'puiux_hub_activation_redirect');
?>
