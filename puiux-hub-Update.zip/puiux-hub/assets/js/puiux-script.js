// PUIUX Hub Scripts
jQuery(document).ready(function($) {
    console.log('PUIUX Hub is loaded.');

    // إضافة سكربتات جديدة للأنيميشن
    lottie.loadAnimation({
        container: document.getElementById('puiux-alert-animation'), // ID of the container element
        renderer: 'svg',
        loop: true,
        autoplay: true,
        path: 'https://lottie.host/80597707-ebd3-4748-bffc-ab51a76c0cd7/PhqEJIcB40.json' // URL to the Lottie animation JSON file
    });

    $('.puiux-content').hover(function() {
        $(this).css('transform', 'scale(1.05)');
    }, function() {
        $(this).css('transform', 'scale(1)');
    });
});

// سكربتات جديدة لصفحة Puipedia
jQuery(document).ready(function($) {
    // Initialize FancyBox
    $('[data-fancybox="video-gallery"]').fancybox({
        buttons: [
            "zoom",
            "share",
            "slideShow",
            "fullScreen",
            "download",
            "thumbs",
            "close"
        ],
        loop: true,
        protect: true
    });
});

// سكربتات جديدة لإعدادات الفيديو
jQuery(document).ready(function($) {
    var videoIndex = $('#puiux-video-repeater .puiux-video-item').length;

    $('#puiux-add-video').on('click', function() {
        var newItem = `
            <div class="puiux-video-item" data-index="${videoIndex}">
                <input type="text" name="puiux_hub_video_data[${videoIndex}][title]" placeholder="${puiux_hub_settings.video_title}" style="width: 100%; margin-bottom: 10px;">
                <input type="text" name="puiux_hub_video_data[${videoIndex}][url]" placeholder="${puiux_hub_settings.video_url}" style="width: 100%; margin-bottom: 10px;">
                <input type="text" name="puiux_hub_video_data[${videoIndex}][thumbnail]" placeholder="${puiux_hub_settings.thumbnail_url}" style="width: 100%; margin-bottom: 10px;">
                <button type="button" class="button button-secondary puiux-remove-video">${puiux_hub_settings.remove}</button>
            </div>
        `;
        $('#puiux-video-repeater').append(newItem);
        videoIndex++;
    });

    $(document).on('click', '.puiux-remove-video', function() {
        $(this).closest('.puiux-video-item').remove();
    });

    // Initialize Sortable
    var el = document.getElementById('puiux-video-repeater');
    Sortable.create(el, {
        animation: 150,
        ghostClass: 'sortable-ghost'
    });
});
