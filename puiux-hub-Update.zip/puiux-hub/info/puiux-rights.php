<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

function puiux_rights_page() {
    ?>
    <div class="wrap puiux-legal-notice-body">
        <div class="puiux-content">
            <img src="https://puiux.com/wp-content/uploads/2021/02/CTA-Icon-Logo.svg" alt="PUIUX Logo" class="puiux-logo">
            <h1 class="puiux-heading"><?php _e('PUIUX Hub - Legal Notice', 'puiux-hub'); ?></h1>
            <div id="puiux-alert-animation" class="puiux-alert-icon"></div>
            <p class="puiux-paragraph">
                <?php _e('This plugin, PUIUX Hub, is developed and maintained by PUIUX. All rights are reserved by PUIUX. The content and functionalities of this plugin are protected by copyright laws and international treaties.', 'puiux-hub'); ?>
            </p>
            <p class="puiux-paragraph">
                <strong><?php _e('Plugin URI:', 'puiux-hub'); ?></strong> <a href="https://puiux.com" class="puiux-link">https://puiux.com</a><br>
                <strong><?php _e('Author:', 'puiux-hub'); ?></strong> PUIUX<br>
                <strong><?php _e('Author URI:', 'puiux-hub'); ?></strong> <a href="https://puiux.com" class="puiux-link">https://puiux.com</a><br>
                <strong><?php _e('Copyright:', 'puiux-hub'); ?></strong> PUIUX (C) 2024. All rights reserved.
            </p>
            <p class="puiux-paragraph">
                <strong><?php _e('Legal Notice:', 'puiux-hub'); ?></strong> <?php _e('Removing or altering this copyright notice is strictly prohibited. Any unauthorized modification or distribution of this plugin is subject to legal action.', 'puiux-hub'); ?>
            </p>
        </div>
    </div>
    <?php
}
?>
