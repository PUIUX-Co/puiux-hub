<?php
function puiux_admin_footer_rights() {
    echo '<span id="footer-thankyou">&copy; 2024 PUIUX. All rights reserved.</span>';
}
?>
