<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

function puiux_hub_puipedia_page() {
    $video_data = get_option('puiux_hub_video_data', array());
    ?>
    <div class="wrap puiux-puipedia-body">
        <h1 class="puiux-heading"><?php _e('PUIUX Puipedia', 'puiux-hub'); ?></h1>
        <div class="puiux-video-container">
            <?php foreach ($video_data as $data) : ?>
                <?php if (!empty($data['url'])) : ?>
                    <div class="puiux-video-box">
                        <a data-fancybox="video-gallery" href="<?php echo esc_url($data['url']); ?>">
                            <img src="<?php echo esc_url($data['thumbnail']); ?>" alt="Video Thumbnail">
                        </a>
                        <div class="puiux-video-title"><?php echo esc_html($data['title']); ?></div>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
            <div style="clear: both;"></div>
        </div>
    </div>
    <?php
}

?>
