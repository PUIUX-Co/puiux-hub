<?php
// Create admin menu
function puiux_hub_admin_menu() {
    add_menu_page(
        __('PUIUX Hub', 'puiux-hub'),
        __('PUIUX Hub', 'puiux-hub'),
        'manage_options', // Capability required to access this menu
        'puiux-hub',
        'puiux_hub_admin_page',
        'dashicons-admin-generic',
        6
    );
    add_submenu_page(
        'puiux-hub',
        __('Settings', 'puiux-hub'),
        __('Settings', 'puiux-hub'),
        'manage_options', // Capability required to access this submenu
        'puiux-hub-settings',
        'puiux_hub_settings_page'
    );
    add_submenu_page(
        'puiux-hub',
        __('Puipedia', 'puiux-hub'),
        __('Puipedia', 'puiux-hub'),
        'manage_options', // Capability required to access this submenu
        'puiux-hub-puipedia',
        'puiux_hub_puipedia_page'
    );
    add_submenu_page(
        'puiux-hub',
        __('Legal Notice', 'puiux-hub'),
        __('Legal Notice', 'puiux-hub'),
        'manage_options',
        'puiux-rights',
        'puiux_rights_page'
    );
}
add_action('admin_menu', 'puiux_hub_admin_menu');

// Admin page content
function puiux_hub_admin_page() {
    ?>
    <div class="wrap">
        <h1><?php _e('PUIUX Hub', 'puiux-hub'); ?></h1>
        <p><?php _e('Welcome to PUIUX Hub, your ultimate solution for integrating and managing multiple PUIUX products.', 'puiux-hub'); ?></p>
        <!-- Add content and settings here -->
    </div>
    <?php
}
?>
