<?php
function puiux_hub_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php _e('Settings', 'puiux-hub'); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('puiux_hub_settings_group');
            do_settings_sections('puiux_hub');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

function puiux_hub_register_settings() {
    register_setting('puiux_hub_settings_group', 'puiux_hub_video_data', array(
        'type' => 'array',
        'sanitize_callback' => 'puiux_sanitize_video_data'
    ));

    add_settings_section(
        'puiux_hub_settings_section',
        __('Video Settings', 'puiux-hub'),
        'puiux_hub_settings_section_callback',
        'puiux_hub'
    );

    add_settings_field(
        'puiux_hub_video_data',
        __('Video Titles, URLs, and Thumbnails', 'puiux-hub'),
        'puiux_hub_video_data_callback',
        'puiux_hub',
        'puiux_hub_settings_section'
    );
}
add_action('admin_init', 'puiux_hub_register_settings');

function puiux_sanitize_video_data($input) {
    if (is_array($input)) {
        foreach ($input as &$data) {
            $data['title'] = sanitize_text_field($data['title']);
            $data['url'] = esc_url_raw($data['url']);
            $data['thumbnail'] = esc_url_raw($data['thumbnail']);
        }
        return $input;
    }
    return array();
}

function puiux_hub_settings_section_callback() {
    echo '<p>' . __('Enter the video titles, URLs, and their thumbnails to display in Puipedia.', 'puiux-hub') . '</p>';
}

function puiux_hub_video_data_callback() {
    $video_data = get_option('puiux_hub_video_data', array());
    ?>
    <div id="puiux-video-repeater">
        <?php foreach ($video_data as $index => $data) : ?>
            <div class="puiux-video-item" data-index="<?php echo $index; ?>">
                <input type="text" name="puiux_hub_video_data[<?php echo $index; ?>][title]" value="<?php echo esc_attr($data['title']); ?>" placeholder="<?php _e('Video Title', 'puiux-hub'); ?>" style="width: 100%; margin-bottom: 10px;">
                <input type="text" name="puiux_hub_video_data[<?php echo $index; ?>][url]" value="<?php echo esc_url($data['url']); ?>" placeholder="<?php _e('Video URL', 'puiux-hub'); ?>" style="width: 100%; margin-bottom: 10px;">
                <input type="text" name="puiux_hub_video_data[<?php echo $index; ?>][thumbnail]" value="<?php echo esc_url($data['thumbnail']); ?>" placeholder="<?php _e('Thumbnail URL', 'puiux-hub'); ?>" style="width: 100%; margin-bottom: 10px;">
                <button type="button" class="button button-secondary puiux-remove-video"><?php _e('Remove', 'puiux-hub'); ?></button>
            </div>
        <?php endforeach; ?>
    </div>
    <button type="button" class="button button-primary" id="puiux-add-video"><?php _e('Add More', 'puiux-hub'); ?></button>
    <?php
}
?>
