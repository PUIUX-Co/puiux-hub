<?php
function puiux_hub_activation_page() {
    ?>
    <div class="wrap">
        <div style="text-align: center; margin-top: 50px;">
            <img src="https://puiux.com/wp-content/uploads/2021/02/CTA-Icon-Logo.svg" alt="PUIUX Logo" style="width: 200px;">
            <h1><?php _e('Thank you for activating PUIUX Hub!', 'puiux-hub'); ?></h1>
            <p><?php _e('You will be redirected to the main page shortly.', 'puiux-hub'); ?></p>
        </div>
    </div>
    <script type="text/javascript">
        setTimeout(function(){
            window.location.href = "<?php echo admin_url('admin.php?page=puiux-hub'); ?>";
        }, 3000);
    </script>
    <?php
}

function puiux_hub_add_activation_page() {
    add_menu_page(
        __('PUIUX Hub Activation', 'puiux-hub'),
        __('PUIUX Hub Activation', 'puiux-hub'),
        'manage_options',
        'puiux-hub-activation',
        'puiux_hub_activation_page',
        'dashicons-yes',
        2
    );
}
add_action('admin_menu', 'puiux_hub_add_activation_page');
?>
