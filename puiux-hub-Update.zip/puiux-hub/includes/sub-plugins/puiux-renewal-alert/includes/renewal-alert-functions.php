<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

function puiux_hub_renewal_alert_page() {
    require_once(plugin_dir_path(__FILE__) . '/../templates/renewal-alert-template.php');
}

// Functions for PUIUX Renewal Alert

function puiux_get_renewal_dates() {
    $domain_renewal_date = get_option('puiux_domain_renewal_date', '');
    $hosting_renewal_date = get_option('puiux_hosting_renewal_date', '');
    return array($domain_renewal_date, $hosting_renewal_date);
}
?>
