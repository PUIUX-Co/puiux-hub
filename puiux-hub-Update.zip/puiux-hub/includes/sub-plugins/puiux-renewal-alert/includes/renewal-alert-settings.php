<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

function puiux_renewal_alert_register_settings() {
    register_setting('puiux_hub_settings_group', 'puiux_domain_renewal_date');
    register_setting('puiux_hub_settings_group', 'puiux_hosting_renewal_date');

    add_settings_section(
        'puiux_renewal_alert_settings_section',
        __('Renewal Dates', 'puiux-hub'),
        'puiux_renewal_alert_settings_section_callback',
        'puiux_hub'
    );

    add_settings_field(
        'puiux_domain_renewal_date',
        __('Domain Renewal Date', 'puiux-hub'),
        'puiux_renewal_alert_domain_renewal_date_callback',
        'puiux_hub',
        'puiux_renewal_alert_settings_section'
    );

    add_settings_field(
        'puiux_hosting_renewal_date',
        __('Hosting Renewal Date', 'puiux-hub'),
        'puiux_renewal_alert_hosting_renewal_date_callback',
        'puiux_hub',
        'puiux_renewal_alert_settings_section'
    );
}
add_action('admin_init', 'puiux_renewal_alert_register_settings');

function puiux_renewal_alert_settings_section_callback() {
    echo '<p>' . __('Enter the renewal dates for your domain and hosting.', 'puiux-hub') . '</p>';
}

function puiux_renewal_alert_domain_renewal_date_callback() {
    $date = get_option('puiux_domain_renewal_date', '');
    echo '<input type="date" name="puiux_domain_renewal_date" value="' . esc_attr($date) . '">';
}

function puiux_renewal_alert_hosting_renewal_date_callback() {
    $date = get_option('puiux_hosting_renewal_date', '');
    echo '<input type="date" name="puiux_hosting_renewal_date" value="' . esc_attr($date) . '">';
}

// Add renewal dates to JavaScript variables
function puiux_add_renewal_dates_to_js() {
    ?>
    <script type="text/javascript">
        var puiux_hub_settings = {
            ajaxurl: '<?php echo admin_url('admin-ajax.php'); ?>',
            domain_renewal_date: '<?php echo get_option('puiux_domain_renewal_date'); ?>',
            hosting_renewal_date: '<?php echo get_option('puiux_hosting_renewal_date'); ?>'
        };
    </script>
    <?php
}
add_action('admin_head', 'puiux_add_renewal_dates_to_js');
?>
