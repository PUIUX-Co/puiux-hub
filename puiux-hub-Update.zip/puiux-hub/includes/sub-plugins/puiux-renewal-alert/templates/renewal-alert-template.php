<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

$domain_renewal_date = get_option('puiux_domain_renewal_date', '');
$hosting_renewal_date = get_option('puiux_hosting_renewal_date', '');
?>
<div class="wrap">
    <h1><?php _e('Renewal Alert', 'puiux-hub'); ?></h1>
    <div id="countdown-container">
        <div class="countdown-box">
            <div id="domain-icon" class="lottie-icon"></div>
            <h2><?php _e('Domain Renewal Countdown', 'puiux-hub'); ?></h2>
            <div id="domain-countdown" data-date="<?php echo esc_attr($domain_renewal_date); ?>"></div>
        </div>
        <div class="countdown-box">
            <div id="hosting-icon" class="lottie-icon"></div>
            <h2><?php _e('Hosting Renewal Countdown', 'puiux-hub'); ?></h2>
            <div id="hosting-countdown" data-date="<?php echo esc_attr($hosting_renewal_date); ?>"></div>
        </div>
    </div>
</div>
