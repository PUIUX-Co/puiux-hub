<?php
/*
Plugin Name: PUIUX Renewal Alert
Description: Sub-plugin for managing domain and hosting renewal countdowns.
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Include necessary files
require_once(plugin_dir_path(__FILE__) . 'includes/renewal-alert-functions.php');
require_once(plugin_dir_path(__FILE__) . 'includes/renewal-alert-settings.php');

// Add submenu page
function puiux_hub_add_renewal_alert_page() {
    add_submenu_page(
        'puiux-hub',
        __('PUIUX Renewal Alert', 'puiux-hub'),
        __('Renewal Alert', 'puiux-hub'),
        'manage_options',
        'puiux-renewal-alert',
        'puiux_hub_renewal_alert_page'
    );
}
add_action('admin_menu', 'puiux_hub_add_renewal_alert_page');

// Enqueue SweetAlert script
function puiux_enqueue_sweetalert_script() {
    wp_enqueue_script('sweetalert', 'https://cdn.jsdelivr.net/npm/sweetalert2@11', array(), null, true);
}
add_action('admin_enqueue_scripts', 'puiux_enqueue_sweetalert_script');

// Function to activate maintenance mode
function activate_maintenance_mode() {
    if (current_user_can('manage_options')) {
        $maintenance_file = ABSPATH . '.maintenance';
        $content = '<?php $upgrading = time(); ?>';
        file_put_contents($maintenance_file, $content);
        update_option('puiux_maintenance_mode', '1');
        error_log("Maintenance mode activated successfully.");
        wp_send_json_success();
    } else {
        error_log("Failed to activate maintenance mode: insufficient permissions.");
        wp_send_json_error('You do not have sufficient permissions to perform this action.');
    }
}
add_action('wp_ajax_activate_maintenance_mode', 'activate_maintenance_mode');

// Function to deactivate maintenance mode
function deactivate_maintenance_mode() {
    if (current_user_can('manage_options')) {
        $maintenance_file = ABSPATH . '.maintenance';
        if (file_exists($maintenance_file)) {
            unlink($maintenance_file);
        }
        update_option('puiux_maintenance_mode', '0');
        error_log("Maintenance mode deactivated successfully.");
        wp_send_json_success();
    } else {
        error_log("Failed to deactivate maintenance mode: insufficient permissions.");
        wp_send_json_error('You do not have sufficient permissions to perform this action.');
    }
}
add_action('wp_ajax_deactivate_maintenance_mode', 'deactivate_maintenance_mode');

// Enqueue renewal alert script and styles
function puiux_hub_enqueue_renewal_alert_scripts($hook_suffix) {
    if ($hook_suffix == 'puiux-hub_page_puiux-renewal-alert') {
        wp_enqueue_script('renewal-alert', plugins_url('assets/js/renewal-alert.js', __FILE__), array('jquery'), null, true);
        wp_enqueue_style('renewal-alert-style', plugins_url('assets/css/renewal-alert.css', __FILE__));
    }
}
add_action('admin_enqueue_scripts', 'puiux_hub_enqueue_renewal_alert_scripts');

// Redirect to maintenance page if maintenance mode is active
if (!function_exists('puiux_hub_redirect_to_maintenance')) {
    function puiux_hub_redirect_to_maintenance() {
        if (get_option('puiux_maintenance_mode') === '1' && !current_user_can('manage_options')) {
            // Clean output buffer to prevent any accidental output
            if (ob_get_length()) ob_clean();
            wp_redirect(plugins_url('maintenance.php', __FILE__));
            exit;
        }
    }
    add_action('template_redirect', 'puiux_hub_redirect_to_maintenance');
}

// Temporary code to check the value of puiux_maintenance_mode
add_action('admin_notices', function() {
    $maintenance_mode = get_option('puiux_maintenance_mode', 'not set');
    echo '<div class="notice notice-info is-dismissible">';
    echo '<p>puiux_maintenance_mode: ' . esc_html($maintenance_mode) . '</p>';
    echo '</div>';
});

// Check user permissions
add_action('admin_notices', function() {
    if (current_user_can('manage_options')) {
        echo '<div class="notice notice-success is-dismissible">';
        echo '<p>Current user has sufficient permissions.</p>';
        echo '</div>';
    } else {
        echo '<div class="notice notice-error is-dismissible">';
        echo '<p>Current user does not have sufficient permissions.</p>';
        echo '</div>';
    }
});

// Test option update
add_action('admin_notices', function() {
    update_option('puiux_test_option', 'test_value');
    $test_option = get_option('puiux_test_option', 'not set');

    if ($test_option === 'test_value') {
        echo '<div class="notice notice-success is-dismissible">';
        echo '<p>Option update test succeeded. Value: ' . esc_html($test_option) . '</p>';
        echo '</div>';
    } else {
        echo '<div class="notice notice-error is-dismissible">';
        echo '<p>Option update test failed. Value: ' . esc_html($test_option) . '</p>';
        echo '</div>';
    }
});

// Add maintenance.php content
function add_maintenance_page_content() {
    if (get_option('puiux_maintenance_mode') === '1' && !current_user_can('manage_options')) {
        include(plugin_dir_path(__FILE__) . 'maintenance.php');
        exit;
    }
}
add_action('get_header', 'add_maintenance_page_content');
