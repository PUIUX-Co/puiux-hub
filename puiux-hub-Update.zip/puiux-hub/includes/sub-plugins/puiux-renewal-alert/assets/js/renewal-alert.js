jQuery(document).ready(function($) {
    console.log('Renewal Alert script loaded.');

    var renewalAlertShown = false;

    // Load Lottie animations
    lottie.loadAnimation({
        container: document.getElementById('domain-icon'), // ID of the container element
        renderer: 'svg',
        loop: true,
        autoplay: true,
        path: 'https://assets5.lottiefiles.com/packages/lf20_jcikwtux.json' // URL to the Lottie animation JSON file
    });

    lottie.loadAnimation({
        container: document.getElementById('hosting-icon'), // ID of the container element
        renderer: 'svg',
        loop: true,
        autoplay: true,
        path: 'https://assets5.lottiefiles.com/packages/lf20_jcikwtux.json' // URL to the Lottie animation JSON file
    });

    function updateCountdown(elementId, endDate) {
        var now = new Date().getTime();
        var end = new Date(endDate).getTime();
        var distance = end - now;

        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        $('#' + elementId).html(days + 'd ' + hours + 'h ' + minutes + 'm ' + seconds + 's ');

        if (distance < 0) {
            $('#' + elementId).html('EXPIRED');
            activateMaintenanceMode();
        }

        // Show SweetAlert popup if less than 30 days remaining and not shown before
        if (days <= 30 && days > 0 && !renewalAlertShown) {
            renewalAlertShown = true;

            Swal.fire({
                title: 'Renewal Alert',
                text: 'Your renewal is approaching. Please take action.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: '<i class="fab fa-whatsapp"></i> Contact Sales',
                cancelButtonText: 'Close',
                footer: '<a href="https://puiux.info/unique/" target="_blank"><i class="fas fa-user"></i> Proceed to Client Area</a>'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.open('https://wa.me/966544420258', '_blank');
                } else {
                    renewalAlertShown = false;
                }
            });
        }
    }

    function activateMaintenanceMode() {
        console.log('Activating maintenance mode...');
        $.ajax({
            url: puiux_hub_settings.ajaxurl,
            method: 'POST',
            data: {
                action: 'activate_maintenance_mode'
            },
            success: function(response) {
                console.log(response); // Debug response
                if (response.success) {
                    console.log('Maintenance mode activated.');
                    window.location.reload();
                } else {
                    console.error('Failed to activate maintenance mode:', response.data);
                    alert('Failed to activate maintenance mode: ' + response.data);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', error);
                alert('Failed to activate maintenance mode: ' + error);
            }
        });
    }

    // Load the renewal dates from the settings
    var domainDate = puiux_hub_settings.domain_renewal_date;
    var hostingDate = puiux_hub_settings.hosting_renewal_date;

    setInterval(function() {
        if (domainDate) {
            updateCountdown('domain-countdown', domainDate);
        }
        if (hostingDate) {
            updateCountdown('hosting-countdown', hostingDate);
        }
    }, 1000);
});
